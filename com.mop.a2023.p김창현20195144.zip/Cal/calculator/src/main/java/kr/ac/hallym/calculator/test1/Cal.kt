package kr.ac.hallym.calculator.test1

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kr.ac.hallym.calculator.databinding.ActivityCalBinding
import net.objecthunter.exp4j.ExpressionBuilder

class Cal : AppCompatActivity() {
    private lateinit var binding: ActivityCalBinding //뷰 바인딩
    private var savedValue: String? = null // 저장된 값

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var tvInput = binding.tvInput //입력 값
        var tvResult = binding.tvResult //출력 값

        //숫자 및 연산자 클릭 리스너
        binding.btnOne.setOnClickListener {
            appendToInput("1")
        }
        binding.btnTwo.setOnClickListener {
            appendToInput("2")
        }
        binding.btnThree.setOnClickListener {
            appendToInput("3")
        }
        binding.btnFour.setOnClickListener {
            appendToInput("4")
        }
        binding.btnFive.setOnClickListener {
            appendToInput("5")
        }
        binding.btnSix.setOnClickListener {
            appendToInput("6")
        }
        binding.btnSeven.setOnClickListener {
            appendToInput("7")
        }
        binding.btnEight.setOnClickListener {
            appendToInput("8")
        }
        binding.btnNine.setOnClickListener {
            appendToInput("9")
        }
        binding.btnZero.setOnClickListener {
            appendToInput("0")
        }
        binding.btnPlus.setOnClickListener {
            appendToInput("+")
        }
        binding.btnSubtract.setOnClickListener {
            appendToInput("-")
        }
        binding.btnMultiply.setOnClickListener {
            appendToInput("x")
        }
        binding.btnDivide.setOnClickListener {
            appendToInput("÷")
        }
        binding.btnDot.setOnClickListener {
            appendToInput(".")
        }
        // = 버튼
        binding.btnEqual.setOnClickListener {
            calculateResult()
        }
        // 초기화 버튼
        binding.btnClear.setOnClickListener {
            binding.tvInput.text = ""
            binding.tvResult.text = ""
        }
        // 지우기 버튼
        binding.btnBack.setOnClickListener {
            // 현재 입력 값을 가져와서 마지막 문자를 제거하고 다시 설정
            val currentInput = binding.tvInput.text.toString()
            if (currentInput.isNotEmpty()) {
                binding.tvInput.text = currentInput.dropLast(1)
            }
        }
        binding.btnSaveIn.setOnClickListener {
            // 현재 입력 값을 가져와서 저장하고, savedValue 변수에 할당
            savedValue = binding.tvInput.text.toString()
            Toast.makeText(this, "값이 저장되었습니다.", Toast.LENGTH_SHORT).show()
        }
        binding.btnSaveOut.setOnClickListener {
            // 저장된 값이 있으면 tvInput에 출력하고, 토스트로 메시지 출력
            if (!savedValue.isNullOrEmpty()) {
                binding.tvInput.text = binding.tvInput.text?.toString() + savedValue.toString()
                Toast.makeText(this, "저장된 값을 불러왔습니다.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "저장된 값이 없습니다.", Toast.LENGTH_SHORT).show()
            }
        }
        //입력한 숫자를 시간으로 인식해 초로 변환후 출력버튼
        binding.secBtn.setOnClickListener {
            try {
                val expression = ExpressionBuilder(binding.tvInput.text.toString()).build()
                val seconds = (expression.evaluate() * 3600).toLong() // 시간을 초로 변환
                binding.tvResult.text = seconds.toString() + "초"
            } catch (e: Exception) {
                Toast.makeText(this, "계산 오류", Toast.LENGTH_SHORT).show() //수식 오류시 토스트메시지
            }
        }
        //입력한 숫자를 시간으로 인식해 분으로 변환후 출력버튼
        binding.minBtn.setOnClickListener {
            try {
                val expression = ExpressionBuilder(binding.tvInput.text.toString()).build()
                val minutes = (expression.evaluate() * 60).toLong() // 시간을 분으로 변환
                binding.tvResult.text = minutes.toString() + "분"
            } catch (e: Exception) {
                Toast.makeText(this, "계산 오류", Toast.LENGTH_SHORT).show() //수식 오류시 토스트메시지
            }
        }




    }
    //tvInput에 입력된 값들을 계산하고 반환해줍니다.
    private fun appendToInput(value: String) {
        val currentInput = binding.tvInput.text.toString()

        val newInput = when (value) {
            "x" -> currentInput + "*" // Change 'x' to '*'
            "÷" -> currentInput + "/" // Change '÷' to '/'
            else -> currentInput + value
        }
        binding.tvInput.text = newInput
    }

    private fun calculateResult() {
        try {
            // exp4j 라이브러리를 사용하여 수식을 계산합니다. - gradle에서 implementation("net.objecthunter:exp4j:0.4.8") 추가
            val expression = ExpressionBuilder(binding.tvInput.text.toString()).build()
            val result = expression.evaluate()

            // 결과를 텍스트뷰에 표시
            binding.tvResult.text = result.toString()
        } catch (e: Exception) {
            // 수식오류 시 토스트로 표시
            Toast.makeText(this, "수식 오류", Toast.LENGTH_SHORT).show()
        }
    }
}